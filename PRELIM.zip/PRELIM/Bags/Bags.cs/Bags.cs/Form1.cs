﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bags.cs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnorder_Click(object sender, EventArgs e)
        {

            double bags;
            bags = Convert.ToDouble(txtbags.Text);

            double bprice = 5.50, lbprice, mbprice, sbprice , totalcost;

            lbprice = Convert.ToDouble(txtlarge.Text);
            mbprice = Convert.ToDouble(txtmedium.Text);
            sbprice = Convert.ToDouble(txtsmall.Text);

            lbprice = lbprice * 3.00;
            mbprice = mbprice * 2.50;
            sbprice = sbprice * 2.00;

            totalcost = (bprice * bags) + lbprice + mbprice + sbprice;

            lbltotal.Text = "Your total cost is: Php " + totalcost.ToString("N2");
            






            
        }

        private void txtbags_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
