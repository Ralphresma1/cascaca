﻿namespace Bags.cs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbags = new System.Windows.Forms.TextBox();
            this.btnorder = new System.Windows.Forms.Button();
            this.lbltotal = new System.Windows.Forms.Label();
            this.lblnumberofbags = new System.Windows.Forms.Label();
            this.lblboxesused = new System.Windows.Forms.Label();
            this.lbllargebox = new System.Windows.Forms.Label();
            this.lblmediumbox = new System.Windows.Forms.Label();
            this.lblsmallbox = new System.Windows.Forms.Label();
            this.txtlarge = new System.Windows.Forms.TextBox();
            this.txtmedium = new System.Windows.Forms.TextBox();
            this.txtsmall = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtbags
            // 
            this.txtbags.Location = new System.Drawing.Point(595, 184);
            this.txtbags.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtbags.Multiline = true;
            this.txtbags.Name = "txtbags";
            this.txtbags.Size = new System.Drawing.Size(159, 21);
            this.txtbags.TabIndex = 1;
            this.txtbags.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbags.TextChanged += new System.EventHandler(this.txtbags_TextChanged);
            // 
            // btnorder
            // 
            this.btnorder.Location = new System.Drawing.Point(787, 180);
            this.btnorder.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnorder.Name = "btnorder";
            this.btnorder.Size = new System.Drawing.Size(123, 30);
            this.btnorder.TabIndex = 2;
            this.btnorder.Text = "Place Order";
            this.btnorder.UseVisualStyleBackColor = true;
            this.btnorder.Click += new System.EventHandler(this.btnorder_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.Location = new System.Drawing.Point(409, 392);
            this.lbltotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(51, 24);
            this.lbltotal.TabIndex = 3;
            this.lbltotal.Text = "Total:";
            this.lbltotal.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblnumberofbags
            // 
            this.lblnumberofbags.AutoSize = true;
            this.lblnumberofbags.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumberofbags.Location = new System.Drawing.Point(381, 181);
            this.lblnumberofbags.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblnumberofbags.Name = "lblnumberofbags";
            this.lblnumberofbags.Size = new System.Drawing.Size(199, 24);
            this.lblnumberofbags.TabIndex = 4;
            this.lblnumberofbags.Text = "Number of Bags Ordered:";
            // 
            // lblboxesused
            // 
            this.lblboxesused.AutoSize = true;
            this.lblboxesused.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblboxesused.Location = new System.Drawing.Point(409, 236);
            this.lblboxesused.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblboxesused.Name = "lblboxesused";
            this.lblboxesused.Size = new System.Drawing.Size(103, 24);
            this.lblboxesused.TabIndex = 5;
            this.lblboxesused.Text = "Boxes Used:";
            // 
            // lbllargebox
            // 
            this.lbllargebox.AllowDrop = true;
            this.lbllargebox.AutoEllipsis = true;
            this.lbllargebox.AutoSize = true;
            this.lbllargebox.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllargebox.Location = new System.Drawing.Point(524, 269);
            this.lbllargebox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbllargebox.Name = "lbllargebox";
            this.lbllargebox.Size = new System.Drawing.Size(56, 24);
            this.lbllargebox.TabIndex = 6;
            this.lbllargebox.Text = "Large:";
            // 
            // lblmediumbox
            // 
            this.lblmediumbox.AutoSize = true;
            this.lblmediumbox.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmediumbox.Location = new System.Drawing.Point(524, 309);
            this.lblmediumbox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblmediumbox.Name = "lblmediumbox";
            this.lblmediumbox.Size = new System.Drawing.Size(75, 24);
            this.lblmediumbox.TabIndex = 7;
            this.lblmediumbox.Text = "Medium:";
            // 
            // lblsmallbox
            // 
            this.lblsmallbox.AutoSize = true;
            this.lblsmallbox.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsmallbox.Location = new System.Drawing.Point(524, 350);
            this.lblsmallbox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsmallbox.Name = "lblsmallbox";
            this.lblsmallbox.Size = new System.Drawing.Size(56, 24);
            this.lblsmallbox.TabIndex = 8;
            this.lblsmallbox.Text = "Small:";
            this.lblsmallbox.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // txtlarge
            // 
            this.txtlarge.Location = new System.Drawing.Point(654, 269);
            this.txtlarge.Name = "txtlarge";
            this.txtlarge.Size = new System.Drawing.Size(100, 22);
            this.txtlarge.TabIndex = 9;
            // 
            // txtmedium
            // 
            this.txtmedium.Location = new System.Drawing.Point(654, 312);
            this.txtmedium.Name = "txtmedium";
            this.txtmedium.Size = new System.Drawing.Size(100, 22);
            this.txtmedium.TabIndex = 10;
            // 
            // txtsmall
            // 
            this.txtsmall.Location = new System.Drawing.Point(654, 353);
            this.txtsmall.Name = "txtsmall";
            this.txtsmall.Size = new System.Drawing.Size(100, 22);
            this.txtsmall.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 773);
            this.Controls.Add(this.txtsmall);
            this.Controls.Add(this.txtmedium);
            this.Controls.Add(this.txtlarge);
            this.Controls.Add(this.lblsmallbox);
            this.Controls.Add(this.lblmediumbox);
            this.Controls.Add(this.lbllargebox);
            this.Controls.Add(this.lblboxesused);
            this.Controls.Add(this.lblnumberofbags);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.btnorder);
            this.Controls.Add(this.txtbags);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtbags;
        private System.Windows.Forms.Button btnorder;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label lblnumberofbags;
        private System.Windows.Forms.Label lblboxesused;
        private System.Windows.Forms.Label lbllargebox;
        private System.Windows.Forms.Label lblmediumbox;
        private System.Windows.Forms.Label lblsmallbox;
        private System.Windows.Forms.TextBox txtlarge;
        private System.Windows.Forms.TextBox txtmedium;
        private System.Windows.Forms.TextBox txtsmall;
    }
}

