﻿namespace Bags.cs
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblbagsordered = new System.Windows.Forms.Label();
            this.lblboxesused = new System.Windows.Forms.Label();
            this.lbllarge = new System.Windows.Forms.Label();
            this.lblmedium = new System.Windows.Forms.Label();
            this.lblsmall = new System.Windows.Forms.Label();
            this.txtbags = new System.Windows.Forms.TextBox();
            this.txtlarge = new System.Windows.Forms.TextBox();
            this.txtmedium = new System.Windows.Forms.TextBox();
            this.txtsmall = new System.Windows.Forms.TextBox();
            this.btncompute = new System.Windows.Forms.Button();
            this.lbltotal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblbagsordered
            // 
            this.lblbagsordered.AutoSize = true;
            this.lblbagsordered.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblbagsordered.Location = new System.Drawing.Point(346, 46);
            this.lblbagsordered.Name = "lblbagsordered";
            this.lblbagsordered.Size = new System.Drawing.Size(240, 28);
            this.lblbagsordered.TabIndex = 0;
            this.lblbagsordered.Text = "Number of Bags Ordered: ";
            // 
            // lblboxesused
            // 
            this.lblboxesused.AutoSize = true;
            this.lblboxesused.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblboxesused.Location = new System.Drawing.Point(372, 98);
            this.lblboxesused.Name = "lblboxesused";
            this.lblboxesused.Size = new System.Drawing.Size(120, 28);
            this.lblboxesused.TabIndex = 1;
            this.lblboxesused.Text = "Boxes Used: ";
            // 
            // lbllarge
            // 
            this.lbllarge.AutoSize = true;
            this.lbllarge.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbllarge.Location = new System.Drawing.Point(428, 150);
            this.lbllarge.Name = "lbllarge";
            this.lbllarge.Size = new System.Drawing.Size(64, 28);
            this.lbllarge.TabIndex = 2;
            this.lbllarge.Text = "Large:";
            // 
            // lblmedium
            // 
            this.lblmedium.AutoSize = true;
            this.lblmedium.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblmedium.Location = new System.Drawing.Point(403, 196);
            this.lblmedium.Name = "lblmedium";
            this.lblmedium.Size = new System.Drawing.Size(89, 28);
            this.lblmedium.TabIndex = 3;
            this.lblmedium.Text = "Medium:";
            // 
            // lblsmall
            // 
            this.lblsmall.AutoSize = true;
            this.lblsmall.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblsmall.Location = new System.Drawing.Point(428, 241);
            this.lblsmall.Name = "lblsmall";
            this.lblsmall.Size = new System.Drawing.Size(64, 28);
            this.lblsmall.TabIndex = 4;
            this.lblsmall.Text = "Small:";
            // 
            // txtbags
            // 
            this.txtbags.Location = new System.Drawing.Point(611, 46);
            this.txtbags.Multiline = true;
            this.txtbags.Name = "txtbags";
            this.txtbags.Size = new System.Drawing.Size(190, 34);
            this.txtbags.TabIndex = 5;
            // 
            // txtlarge
            // 
            this.txtlarge.Location = new System.Drawing.Point(516, 154);
            this.txtlarge.Multiline = true;
            this.txtlarge.Name = "txtlarge";
            this.txtlarge.Size = new System.Drawing.Size(186, 34);
            this.txtlarge.TabIndex = 6;
            // 
            // txtmedium
            // 
            this.txtmedium.Location = new System.Drawing.Point(516, 200);
            this.txtmedium.Multiline = true;
            this.txtmedium.Name = "txtmedium";
            this.txtmedium.Size = new System.Drawing.Size(186, 34);
            this.txtmedium.TabIndex = 7;
            // 
            // txtsmall
            // 
            this.txtsmall.Location = new System.Drawing.Point(516, 245);
            this.txtsmall.Multiline = true;
            this.txtsmall.Name = "txtsmall";
            this.txtsmall.Size = new System.Drawing.Size(186, 34);
            this.txtsmall.TabIndex = 8;
            // 
            // btncompute
            // 
            this.btncompute.Location = new System.Drawing.Point(559, 301);
            this.btncompute.Name = "btncompute";
            this.btncompute.Size = new System.Drawing.Size(94, 29);
            this.btncompute.TabIndex = 9;
            this.btncompute.Text = "Compute";
            this.btncompute.UseVisualStyleBackColor = true;
            this.btncompute.Click += new System.EventHandler(this.btncompute_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbltotal.Location = new System.Drawing.Point(336, 334);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(156, 28);
            this.lbltotal.TabIndex = 10;
            this.lbltotal.Text = "The Total Cost is:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1306, 450);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.btncompute);
            this.Controls.Add(this.txtsmall);
            this.Controls.Add(this.txtmedium);
            this.Controls.Add(this.txtlarge);
            this.Controls.Add(this.txtbags);
            this.Controls.Add(this.lblsmall);
            this.Controls.Add(this.lblmedium);
            this.Controls.Add(this.lbllarge);
            this.Controls.Add(this.lblboxesused);
            this.Controls.Add(this.lblbagsordered);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblbagsordered;
        private Label lblboxesused;
        private Label lbllarge;
        private Label lblmedium;
        private Label lblsmall;
        private TextBox txtbags;
        private TextBox txtlarge;
        private TextBox txtmedium;
        private TextBox txtsmall;
        private Button btncompute;
        private Label lbltotal;
    }
}