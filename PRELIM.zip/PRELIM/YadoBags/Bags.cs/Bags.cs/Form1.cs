namespace Bags.cs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncompute_Click(object sender, EventArgs e)
        {
            double bags;
            bags = Convert.ToDouble(txtbags.Text);

            double bprice = 5.50, lbprice, mbprice, sbprice, total;

            lbprice = Convert.ToDouble(txtlarge.Text);
            mbprice = Convert.ToDouble(txtmedium.Text);
            sbprice = Convert.ToDouble(txtsmall.Text);

            lbprice = lbprice * 3.00;
            mbprice = mbprice * 2.50;
            sbprice = sbprice * 2.00;

            total = (bprice * bags) + lbprice + mbprice + sbprice;

            lbltotal.Text = "The Total Cost is: Php " + total.ToString("N2");

        }
    }
}
