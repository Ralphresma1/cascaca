﻿namespace Flags.cs
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblflagviewer = new System.Windows.Forms.Label();
            this.lblcountry = new System.Windows.Forms.Label();
            this.lblprogrammer = new System.Windows.Forms.Label();
            this.gbdisplay = new System.Windows.Forms.GroupBox();
            this.cbtitle = new System.Windows.Forms.CheckBox();
            this.cbprogrammer = new System.Windows.Forms.CheckBox();
            this.cbcountryname = new System.Windows.Forms.CheckBox();
            this.gbcountry = new System.Windows.Forms.GroupBox();
            this.rbfrance = new System.Windows.Forms.RadioButton();
            this.rbusa = new System.Windows.Forms.RadioButton();
            this.rbcolumbia = new System.Windows.Forms.RadioButton();
            this.rbphilippines = new System.Windows.Forms.RadioButton();
            this.pbcountry = new System.Windows.Forms.PictureBox();
            this.gbdisplay.SuspendLayout();
            this.gbcountry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbcountry)).BeginInit();
            this.SuspendLayout();
            // 
            // lblflagviewer
            // 
            this.lblflagviewer.AutoSize = true;
            this.lblflagviewer.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblflagviewer.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblflagviewer.Location = new System.Drawing.Point(523, 9);
            this.lblflagviewer.Name = "lblflagviewer";
            this.lblflagviewer.Size = new System.Drawing.Size(206, 46);
            this.lblflagviewer.TabIndex = 0;
            this.lblflagviewer.Text = "Flag Viewer";
            this.lblflagviewer.Click += new System.EventHandler(this.lblflagviewer_Click);
            // 
            // lblcountry
            // 
            this.lblcountry.AutoSize = true;
            this.lblcountry.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblcountry.Location = new System.Drawing.Point(523, 307);
            this.lblcountry.Name = "lblcountry";
            this.lblcountry.Size = new System.Drawing.Size(197, 46);
            this.lblcountry.TabIndex = 1;
            this.lblcountry.Text = "Philippines";
            this.lblcountry.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblprogrammer
            // 
            this.lblprogrammer.AutoSize = true;
            this.lblprogrammer.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblprogrammer.Location = new System.Drawing.Point(77, 373);
            this.lblprogrammer.Name = "lblprogrammer";
            this.lblprogrammer.Size = new System.Drawing.Size(273, 27);
            this.lblprogrammer.TabIndex = 2;
            this.lblprogrammer.Text = "Beligaño, Lord Christian";
            // 
            // gbdisplay
            // 
            this.gbdisplay.Controls.Add(this.cbtitle);
            this.gbdisplay.Controls.Add(this.cbprogrammer);
            this.gbdisplay.Controls.Add(this.cbcountryname);
            this.gbdisplay.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.gbdisplay.Location = new System.Drawing.Point(846, 76);
            this.gbdisplay.Name = "gbdisplay";
            this.gbdisplay.Size = new System.Drawing.Size(180, 206);
            this.gbdisplay.TabIndex = 3;
            this.gbdisplay.TabStop = false;
            this.gbdisplay.Text = "Display";
            // 
            // cbtitle
            // 
            this.cbtitle.AutoSize = true;
            this.cbtitle.Checked = true;
            this.cbtitle.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbtitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbtitle.Location = new System.Drawing.Point(6, 49);
            this.cbtitle.Name = "cbtitle";
            this.cbtitle.Size = new System.Drawing.Size(71, 32);
            this.cbtitle.TabIndex = 6;
            this.cbtitle.Text = "Title";
            this.cbtitle.UseVisualStyleBackColor = true;
            this.cbtitle.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // cbprogrammer
            // 
            this.cbprogrammer.AutoSize = true;
            this.cbprogrammer.Checked = true;
            this.cbprogrammer.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbprogrammer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbprogrammer.Location = new System.Drawing.Point(6, 125);
            this.cbprogrammer.Name = "cbprogrammer";
            this.cbprogrammer.Size = new System.Drawing.Size(144, 32);
            this.cbprogrammer.TabIndex = 2;
            this.cbprogrammer.Text = "Programmer";
            this.cbprogrammer.UseVisualStyleBackColor = true;
            this.cbprogrammer.CheckedChanged += new System.EventHandler(this.cbprogrammer_CheckedChanged);
            // 
            // cbcountryname
            // 
            this.cbcountryname.AutoSize = true;
            this.cbcountryname.Checked = true;
            this.cbcountryname.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbcountryname.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbcountryname.Location = new System.Drawing.Point(6, 87);
            this.cbcountryname.Name = "cbcountryname";
            this.cbcountryname.Size = new System.Drawing.Size(161, 32);
            this.cbcountryname.TabIndex = 1;
            this.cbcountryname.Text = "Country Name";
            this.cbcountryname.UseVisualStyleBackColor = true;
            this.cbcountryname.CheckedChanged += new System.EventHandler(this.cbcountryname_CheckedChanged);
            // 
            // gbcountry
            // 
            this.gbcountry.Controls.Add(this.rbfrance);
            this.gbcountry.Controls.Add(this.rbusa);
            this.gbcountry.Controls.Add(this.rbcolumbia);
            this.gbcountry.Controls.Add(this.rbphilippines);
            this.gbcountry.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.gbcountry.Location = new System.Drawing.Point(198, 76);
            this.gbcountry.Name = "gbcountry";
            this.gbcountry.Size = new System.Drawing.Size(186, 206);
            this.gbcountry.TabIndex = 4;
            this.gbcountry.TabStop = false;
            this.gbcountry.Text = "Country";
            // 
            // rbfrance
            // 
            this.rbfrance.AutoSize = true;
            this.rbfrance.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbfrance.Location = new System.Drawing.Point(13, 123);
            this.rbfrance.Name = "rbfrance";
            this.rbfrance.Size = new System.Drawing.Size(90, 32);
            this.rbfrance.TabIndex = 3;
            this.rbfrance.Text = "France";
            this.rbfrance.UseVisualStyleBackColor = true;
            this.rbfrance.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // rbusa
            // 
            this.rbusa.AutoSize = true;
            this.rbusa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbusa.Location = new System.Drawing.Point(13, 93);
            this.rbusa.Name = "rbusa";
            this.rbusa.Size = new System.Drawing.Size(71, 32);
            this.rbusa.TabIndex = 2;
            this.rbusa.Text = "USA";
            this.rbusa.UseVisualStyleBackColor = true;
            this.rbusa.CheckedChanged += new System.EventHandler(this.rbusa_CheckedChanged);
            // 
            // rbcolumbia
            // 
            this.rbcolumbia.AutoSize = true;
            this.rbcolumbia.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbcolumbia.Location = new System.Drawing.Point(13, 63);
            this.rbcolumbia.Name = "rbcolumbia";
            this.rbcolumbia.Size = new System.Drawing.Size(117, 32);
            this.rbcolumbia.TabIndex = 1;
            this.rbcolumbia.Text = "Columbia";
            this.rbcolumbia.UseVisualStyleBackColor = true;
            this.rbcolumbia.CheckedChanged += new System.EventHandler(this.rbcolumbia_CheckedChanged);
            // 
            // rbphilippines
            // 
            this.rbphilippines.AutoSize = true;
            this.rbphilippines.Checked = true;
            this.rbphilippines.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbphilippines.Location = new System.Drawing.Point(13, 33);
            this.rbphilippines.Name = "rbphilippines";
            this.rbphilippines.Size = new System.Drawing.Size(128, 32);
            this.rbphilippines.TabIndex = 0;
            this.rbphilippines.TabStop = true;
            this.rbphilippines.Text = "Philippines";
            this.rbphilippines.UseVisualStyleBackColor = true;
            this.rbphilippines.CheckedChanged += new System.EventHandler(this.rbphilippines_CheckedChanged);
            // 
            // pbcountry
            // 
            this.pbcountry.Image = global::Flags.cs.Properties.Resources.philippines;
            this.pbcountry.Location = new System.Drawing.Point(413, 76);
            this.pbcountry.Name = "pbcountry";
            this.pbcountry.Size = new System.Drawing.Size(401, 206);
            this.pbcountry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbcountry.TabIndex = 5;
            this.pbcountry.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 450);
            this.Controls.Add(this.pbcountry);
            this.Controls.Add(this.gbcountry);
            this.Controls.Add(this.gbdisplay);
            this.Controls.Add(this.lblprogrammer);
            this.Controls.Add(this.lblcountry);
            this.Controls.Add(this.lblflagviewer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbdisplay.ResumeLayout(false);
            this.gbdisplay.PerformLayout();
            this.gbcountry.ResumeLayout(false);
            this.gbcountry.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbcountry)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblflagviewer;
        private Label lblcountry;
        private Label lblprogrammer;
        private GroupBox gbdisplay;
        private CheckBox cbprogrammer;
        private CheckBox cbcountryname;
        private GroupBox gbcountry;
        private RadioButton rbfrance;
        private RadioButton rbusa;
        private RadioButton rbcolumbia;
        private RadioButton rbphilippines;
        private PictureBox pbcountry;
        private CheckBox cbtitle;
    }
}