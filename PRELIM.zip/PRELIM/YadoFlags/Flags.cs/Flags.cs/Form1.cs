namespace Flags.cs
{
    public partial class Form1 : Form
    {
        string country;
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            country = "France";
            lblcountry.Text = country;
            pbcountry.Image = Properties.Resources.France;
        }

        private void rbphilippines_CheckedChanged(object sender, EventArgs e)
        {
            country = "Philippines";
            lblcountry.Text = country;
            pbcountry.Image = Properties.Resources.philippines;
        }

        private void rbcolumbia_CheckedChanged(object sender, EventArgs e)
        {
            country = "Colombia";
            lblcountry.Text = country;
            pbcountry.Image = Properties.Resources.colombia;
        }

        private void rbusa_CheckedChanged(object sender, EventArgs e)
        {
            country = "USA";
            lblcountry.Text = country;
            pbcountry.Image = Properties.Resources.USA;
        }

        private void lblflagviewer_Click(object sender, EventArgs e)
        {
           
        }

        private void cbtitle_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (cbtitle.Checked)
            {
                lblflagviewer.Visible = true;
            }
            else
            {
                lblflagviewer.Visible = false;
            }
        }

        private void cbcountryname_CheckedChanged(object sender, EventArgs e)
        {
            if (cbcountryname.Checked)
            {
                lblcountry.Visible = true;
            }
            else
            {
                lblcountry.Visible = false;
            }
        }

        private void cbprogrammer_CheckedChanged(object sender, EventArgs e)
        {
            if (cbprogrammer.Checked)
            {
                lblprogrammer.Visible = true;
            }
            else
            {
                lblprogrammer.Visible = false;
            }
        }
    }
}