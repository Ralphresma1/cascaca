namespace flags.cs
{
    public partial class Form1 : Form
    {
        string country;
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void cbtitle_CheckedChanged(object sender, EventArgs e)
        {
            if (cbtitle.Checked)
            {
                FlagViewerLabel.Visible = true;
            }
            else
            {
                FlagViewerLabel.Visible = false;
            }
        }

        private void rbphilippines_CheckedChanged(object sender, EventArgs e)
        {
            country = "Philippines";
            lblflag.Text = country;
            pictureBox1.Image = Properties.Resources.philippines;
        }

        private void rbcolumbia_CheckedChanged(object sender, EventArgs e)
        {
            country = "Columbia";
            lblflag.Text = country;
            pictureBox1.Image = Properties.Resources.colombia;
        }

        private void rbUSA_CheckedChanged(object sender, EventArgs e)
        {
            country = "USA";
           lblflag.Text = country;
            pictureBox1.Image = Properties.Resources.USA;
        }

        private void rbfrance_CheckedChanged(object sender, EventArgs e)
        {
            country = "France";
            lblflag.Text = country;
            pictureBox1.Image = Properties.Resources.France;
        }

        private void CountryNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void lblflag_Click(object sender, EventArgs e)
        {

        }
    }
}