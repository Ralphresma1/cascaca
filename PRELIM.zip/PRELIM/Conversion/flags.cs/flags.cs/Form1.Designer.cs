﻿namespace flags.cs
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbdisplay = new System.Windows.Forms.GroupBox();
            this.cbprogrammer = new System.Windows.Forms.CheckBox();
            this.cbcountryname = new System.Windows.Forms.CheckBox();
            this.cbtitle = new System.Windows.Forms.CheckBox();
            this.gbcountry = new System.Windows.Forms.GroupBox();
            this.rbfrance = new System.Windows.Forms.RadioButton();
            this.rbUSA = new System.Windows.Forms.RadioButton();
            this.rbcolumbia = new System.Windows.Forms.RadioButton();
            this.rbphilippines = new System.Windows.Forms.RadioButton();
            this.FlagViewerLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblflag = new System.Windows.Forms.Label();
            this.gbdisplay.SuspendLayout();
            this.gbcountry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gbdisplay
            // 
            this.gbdisplay.Controls.Add(this.cbprogrammer);
            this.gbdisplay.Controls.Add(this.cbcountryname);
            this.gbdisplay.Controls.Add(this.cbtitle);
            this.gbdisplay.Location = new System.Drawing.Point(799, 71);
            this.gbdisplay.Name = "gbdisplay";
            this.gbdisplay.Size = new System.Drawing.Size(182, 178);
            this.gbdisplay.TabIndex = 0;
            this.gbdisplay.TabStop = false;
            this.gbdisplay.Text = "Display";
            this.gbdisplay.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // cbprogrammer
            // 
            this.cbprogrammer.AutoSize = true;
            this.cbprogrammer.Location = new System.Drawing.Point(17, 122);
            this.cbprogrammer.Name = "cbprogrammer";
            this.cbprogrammer.Size = new System.Drawing.Size(114, 24);
            this.cbprogrammer.TabIndex = 2;
            this.cbprogrammer.Text = "Programmer";
            this.cbprogrammer.UseVisualStyleBackColor = true;
            // 
            // cbcountryname
            // 
            this.cbcountryname.AutoSize = true;
            this.cbcountryname.Location = new System.Drawing.Point(17, 77);
            this.cbcountryname.Name = "cbcountryname";
            this.cbcountryname.Size = new System.Drawing.Size(126, 24);
            this.cbcountryname.TabIndex = 1;
            this.cbcountryname.Text = "Country Name";
            this.cbcountryname.UseVisualStyleBackColor = true;
            this.cbcountryname.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // cbtitle
            // 
            this.cbtitle.AutoSize = true;
            this.cbtitle.Location = new System.Drawing.Point(17, 32);
            this.cbtitle.Name = "cbtitle";
            this.cbtitle.Size = new System.Drawing.Size(60, 24);
            this.cbtitle.TabIndex = 0;
            this.cbtitle.Text = "Title";
            this.cbtitle.UseVisualStyleBackColor = true;
            this.cbtitle.CheckedChanged += new System.EventHandler(this.cbtitle_CheckedChanged);
            // 
            // gbcountry
            // 
            this.gbcountry.Controls.Add(this.rbfrance);
            this.gbcountry.Controls.Add(this.rbUSA);
            this.gbcountry.Controls.Add(this.rbcolumbia);
            this.gbcountry.Controls.Add(this.rbphilippines);
            this.gbcountry.Location = new System.Drawing.Point(323, 71);
            this.gbcountry.Name = "gbcountry";
            this.gbcountry.Size = new System.Drawing.Size(159, 178);
            this.gbcountry.TabIndex = 1;
            this.gbcountry.TabStop = false;
            this.gbcountry.Text = "Country";
            // 
            // rbfrance
            // 
            this.rbfrance.AutoSize = true;
            this.rbfrance.Location = new System.Drawing.Point(15, 125);
            this.rbfrance.Name = "rbfrance";
            this.rbfrance.Size = new System.Drawing.Size(73, 24);
            this.rbfrance.TabIndex = 3;
            this.rbfrance.TabStop = true;
            this.rbfrance.Text = "France";
            this.rbfrance.UseVisualStyleBackColor = true;
            this.rbfrance.CheckedChanged += new System.EventHandler(this.rbfrance_CheckedChanged);
            // 
            // rbUSA
            // 
            this.rbUSA.AutoSize = true;
            this.rbUSA.Location = new System.Drawing.Point(15, 95);
            this.rbUSA.Name = "rbUSA";
            this.rbUSA.Size = new System.Drawing.Size(58, 24);
            this.rbUSA.TabIndex = 2;
            this.rbUSA.TabStop = true;
            this.rbUSA.Text = "USA";
            this.rbUSA.UseVisualStyleBackColor = true;
            this.rbUSA.CheckedChanged += new System.EventHandler(this.rbUSA_CheckedChanged);
            // 
            // rbcolumbia
            // 
            this.rbcolumbia.AutoSize = true;
            this.rbcolumbia.Location = new System.Drawing.Point(15, 65);
            this.rbcolumbia.Name = "rbcolumbia";
            this.rbcolumbia.Size = new System.Drawing.Size(94, 24);
            this.rbcolumbia.TabIndex = 1;
            this.rbcolumbia.TabStop = true;
            this.rbcolumbia.Text = "Columbia";
            this.rbcolumbia.UseVisualStyleBackColor = true;
            this.rbcolumbia.CheckedChanged += new System.EventHandler(this.rbcolumbia_CheckedChanged);
            // 
            // rbphilippines
            // 
            this.rbphilippines.AutoSize = true;
            this.rbphilippines.Location = new System.Drawing.Point(15, 35);
            this.rbphilippines.Name = "rbphilippines";
            this.rbphilippines.Size = new System.Drawing.Size(102, 24);
            this.rbphilippines.TabIndex = 0;
            this.rbphilippines.TabStop = true;
            this.rbphilippines.Text = "Philippines";
            this.rbphilippines.UseVisualStyleBackColor = true;
            this.rbphilippines.CheckedChanged += new System.EventHandler(this.rbphilippines_CheckedChanged);
            // 
            // FlagViewerLabel
            // 
            this.FlagViewerLabel.AutoSize = true;
            this.FlagViewerLabel.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FlagViewerLabel.Location = new System.Drawing.Point(559, 27);
            this.FlagViewerLabel.Name = "FlagViewerLabel";
            this.FlagViewerLabel.Size = new System.Drawing.Size(160, 38);
            this.FlagViewerLabel.TabIndex = 3;
            this.FlagViewerLabel.Text = "Flag Viewer";
            this.FlagViewerLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::flags.cs.Properties.Resources.colombia;
            this.pictureBox1.Location = new System.Drawing.Point(510, 79);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(269, 141);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // lblflag
            // 
            this.lblflag.AutoSize = true;
            this.lblflag.Location = new System.Drawing.Point(613, 260);
            this.lblflag.Name = "lblflag";
            this.lblflag.Size = new System.Drawing.Size(50, 20);
            this.lblflag.TabIndex = 5;
            this.lblflag.Text = "label1";
            this.lblflag.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblflag.Click += new System.EventHandler(this.lblflag_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1341, 450);
            this.Controls.Add(this.lblflag);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.FlagViewerLabel);
            this.Controls.Add(this.gbcountry);
            this.Controls.Add(this.gbdisplay);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gbdisplay.ResumeLayout(false);
            this.gbdisplay.PerformLayout();
            this.gbcountry.ResumeLayout(false);
            this.gbcountry.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox gbdisplay;
        private GroupBox gbcountry;
        private CheckBox cbprogrammer;
        private CheckBox cbcountryname;
        private CheckBox cbtitle;
        private RadioButton rbfrance;
        private RadioButton rbUSA;
        private RadioButton rbcolumbia;
        private RadioButton rbphilippines;
        private Label FlagViewerLabel;
        private PictureBox pictureBox1;
        private Label lblflag;
    }
}