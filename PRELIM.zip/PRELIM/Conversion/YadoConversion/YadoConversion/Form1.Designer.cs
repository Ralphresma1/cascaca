﻿namespace YadoConversion
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbllength = new System.Windows.Forms.Label();
            this.txtlength = new System.Windows.Forms.TextBox();
            this.btnconvert = new System.Windows.Forms.Button();
            this.lblresult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbllength
            // 
            this.lbllength.AutoSize = true;
            this.lbllength.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbllength.Location = new System.Drawing.Point(443, 118);
            this.lbllength.Name = "lbllength";
            this.lbllength.Size = new System.Drawing.Size(239, 38);
            this.lbllength.TabIndex = 0;
            this.lbllength.Text = "Enter Length >>>";
            // 
            // txtlength
            // 
            this.txtlength.Location = new System.Drawing.Point(680, 122);
            this.txtlength.Multiline = true;
            this.txtlength.Name = "txtlength";
            this.txtlength.Size = new System.Drawing.Size(238, 34);
            this.txtlength.TabIndex = 1;
            // 
            // btnconvert
            // 
            this.btnconvert.Location = new System.Drawing.Point(613, 180);
            this.btnconvert.Name = "btnconvert";
            this.btnconvert.Size = new System.Drawing.Size(115, 34);
            this.btnconvert.TabIndex = 5;
            this.btnconvert.Text = "convert";
            this.btnconvert.UseVisualStyleBackColor = true;
            this.btnconvert.Click += new System.EventHandler(this.btnconvert_Click);
            // 
            // lblresult
            // 
            this.lblresult.AutoSize = true;
            this.lblresult.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblresult.Location = new System.Drawing.Point(499, 248);
            this.lblresult.Name = "lblresult";
            this.lblresult.Size = new System.Drawing.Size(68, 28);
            this.lblresult.TabIndex = 6;
            this.lblresult.Text = "Result:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1394, 507);
            this.Controls.Add(this.lblresult);
            this.Controls.Add(this.btnconvert);
            this.Controls.Add(this.txtlength);
            this.Controls.Add(this.lbllength);
            this.Name = "Form1";
            this.Text = ".";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbllength;
        private TextBox txtlength;
        private Button btnconvert;
        private Label lblresult;
    }
}