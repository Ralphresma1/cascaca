namespace YadoConversion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnconvert_Click(object sender, EventArgs e)
        {
            double cm = Convert.ToDouble(txtlength.Text);

            double inches = cm / 2.54;
            int yards = (int)(inches / 36);
            int feet = (int)((inches % 36) / 12);

            int Inches = (int)(inches % 12);

            lblresult.Text = yards + " yards " + feet + " feet (foot) " + Inches + " inches ";
        }
    }
}