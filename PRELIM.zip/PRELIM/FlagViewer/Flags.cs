﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.4.33213.308
MinimumVisualStudioVersion = 10.0.40219.1
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "Flags.cs", "Flags.cs.csproj", "{E29295BE-BA14-4AE9-9425-B69ADF6E0D3D}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|Any CPU = Debug|Any CPU
		Release|Any CPU = Release|Any CPU
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{E29295BE-BA14-4AE9-9425-B69ADF6E0D3D}.Debug|Any CPU.ActiveCfg = Debug|Any CPU
		{E29295BE-BA14-4AE9-9425-B69ADF6E0D3D}.Debug|Any CPU.Build.0 = Debug|Any CPU
		{E29295BE-BA14-4AE9-9425-B69ADF6E0D3D}.Release|Any CPU.ActiveCfg = Release|Any CPU
		{E29295BE-BA14-4AE9-9425-B69ADF6E0D3D}.Release|Any CPU.Build.0 = Release|Any CPU
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {7A7972A3-0C21-4973-8FC7-086F725463DC}
	EndGlobalSection
EndGlobal
