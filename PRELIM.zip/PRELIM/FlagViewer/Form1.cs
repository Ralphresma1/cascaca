﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flags.cs
{
    public partial class Form1 : Form
    {
        string country; 
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            country = "Philippines";
            CountryNameLabel.Text = country;
            pictureBox1.Image = Properties.Resources.philippines;
           
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            string programmer  = "Ralph Oscar O. Resma";
            ProgrammerLabel.Text = programmer; 
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ColombiaRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            country = "Colombia";
            CountryNameLabel.Text = country;
            pictureBox1.Image = Properties.Resources.colombia;

        }

        private void USARadioButton_CheckedChanged(object sender, EventArgs e)
        {
            country = "USA";
            CountryNameLabel.Text = country;
            pictureBox1.Image = Properties.Resources.USA;
        }

        private void FranceRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            country = "France";
            CountryNameLabel.Text = country;
            pictureBox1.Image = Properties.Resources.France;

        }

        private void ProgrammerLabel_TextChanged(object sender, EventArgs e)
        {
            if (TitleCheckBox.Checked)
            {
                ProgrammerLabel.Visible= true;  
            }
            else
            {
                ProgrammerLabel.Visible = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void TitleCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            string title = "Flag Viewer";
            FlagViewerLabel.Text = title;

        }

        private void CountryNameLabel_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void CountryNameCheckBox_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FlagViewerLabel_Click(object sender, EventArgs e)
        {
            if(TitleCheckBox.Checked)
            {
                FlagViewerLabel.Visible = true;
            }
            else
            {
                FlagViewerLabel.Visible = false;    
            }
        }
    }
}
