﻿namespace Flags.cs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FlagViewerLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FranceRadioButton = new System.Windows.Forms.RadioButton();
            this.USARadioButton = new System.Windows.Forms.RadioButton();
            this.ColombiaRadioButton = new System.Windows.Forms.RadioButton();
            this.PhilippinesRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ProgrammerCheckBox = new System.Windows.Forms.CheckBox();
            this.CountryNameCheckBox = new System.Windows.Forms.CheckBox();
            this.TitleCheckBox = new System.Windows.Forms.CheckBox();
            this.CountryNameLabel = new System.Windows.Forms.TextBox();
            this.ProgrammerLabel = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // FlagViewerLabel
            // 
            this.FlagViewerLabel.AutoSize = true;
            this.FlagViewerLabel.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FlagViewerLabel.Location = new System.Drawing.Point(616, 45);
            this.FlagViewerLabel.Name = "FlagViewerLabel";
            this.FlagViewerLabel.Size = new System.Drawing.Size(182, 35);
            this.FlagViewerLabel.TabIndex = 0;
            this.FlagViewerLabel.Text = "Flag Viewer";
            this.FlagViewerLabel.Click += new System.EventHandler(this.FlagViewerLabel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FranceRadioButton);
            this.groupBox1.Controls.Add(this.USARadioButton);
            this.groupBox1.Controls.Add(this.ColombiaRadioButton);
            this.groupBox1.Controls.Add(this.PhilippinesRadioButton);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(379, 99);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(152, 193);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Country";
            // 
            // FranceRadioButton
            // 
            this.FranceRadioButton.AutoSize = true;
            this.FranceRadioButton.Location = new System.Drawing.Point(18, 133);
            this.FranceRadioButton.Name = "FranceRadioButton";
            this.FranceRadioButton.Size = new System.Drawing.Size(82, 23);
            this.FranceRadioButton.TabIndex = 3;
            this.FranceRadioButton.Text = "France";
            this.FranceRadioButton.UseVisualStyleBackColor = true;
            this.FranceRadioButton.CheckedChanged += new System.EventHandler(this.FranceRadioButton_CheckedChanged);
            // 
            // USARadioButton
            // 
            this.USARadioButton.AutoSize = true;
            this.USARadioButton.Location = new System.Drawing.Point(18, 101);
            this.USARadioButton.Name = "USARadioButton";
            this.USARadioButton.Size = new System.Drawing.Size(63, 23);
            this.USARadioButton.TabIndex = 2;
            this.USARadioButton.Text = "USA";
            this.USARadioButton.UseVisualStyleBackColor = true;
            this.USARadioButton.CheckedChanged += new System.EventHandler(this.USARadioButton_CheckedChanged);
            // 
            // ColombiaRadioButton
            // 
            this.ColombiaRadioButton.AutoSize = true;
            this.ColombiaRadioButton.Location = new System.Drawing.Point(18, 69);
            this.ColombiaRadioButton.Name = "ColombiaRadioButton";
            this.ColombiaRadioButton.Size = new System.Drawing.Size(98, 23);
            this.ColombiaRadioButton.TabIndex = 1;
            this.ColombiaRadioButton.Text = "Colombia";
            this.ColombiaRadioButton.UseVisualStyleBackColor = true;
            this.ColombiaRadioButton.CheckedChanged += new System.EventHandler(this.ColombiaRadioButton_CheckedChanged);
            // 
            // PhilippinesRadioButton
            // 
            this.PhilippinesRadioButton.AutoSize = true;
            this.PhilippinesRadioButton.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.PhilippinesRadioButton.Location = new System.Drawing.Point(18, 37);
            this.PhilippinesRadioButton.Name = "PhilippinesRadioButton";
            this.PhilippinesRadioButton.Size = new System.Drawing.Size(109, 23);
            this.PhilippinesRadioButton.TabIndex = 0;
            this.PhilippinesRadioButton.Text = "Philippines";
            this.PhilippinesRadioButton.UseVisualStyleBackColor = true;
            this.PhilippinesRadioButton.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ProgrammerCheckBox);
            this.groupBox2.Controls.Add(this.CountryNameCheckBox);
            this.groupBox2.Controls.Add(this.TitleCheckBox);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(884, 99);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(174, 193);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Display";
            // 
            // ProgrammerCheckBox
            // 
            this.ProgrammerCheckBox.AutoSize = true;
            this.ProgrammerCheckBox.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.ProgrammerCheckBox.Location = new System.Drawing.Point(13, 133);
            this.ProgrammerCheckBox.Name = "ProgrammerCheckBox";
            this.ProgrammerCheckBox.Size = new System.Drawing.Size(122, 23);
            this.ProgrammerCheckBox.TabIndex = 2;
            this.ProgrammerCheckBox.Text = "Programmer";
            this.ProgrammerCheckBox.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.ProgrammerCheckBox.UseVisualStyleBackColor = true;
            this.ProgrammerCheckBox.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // CountryNameCheckBox
            // 
            this.CountryNameCheckBox.AutoSize = true;
            this.CountryNameCheckBox.Location = new System.Drawing.Point(13, 86);
            this.CountryNameCheckBox.Name = "CountryNameCheckBox";
            this.CountryNameCheckBox.Size = new System.Drawing.Size(136, 23);
            this.CountryNameCheckBox.TabIndex = 1;
            this.CountryNameCheckBox.Text = "Country Name";
            this.CountryNameCheckBox.UseVisualStyleBackColor = true;
            this.CountryNameCheckBox.CheckedChanged += new System.EventHandler(this.CountryNameCheckBox_CheckedChanged);
            // 
            // TitleCheckBox
            // 
            this.TitleCheckBox.AutoSize = true;
            this.TitleCheckBox.Location = new System.Drawing.Point(13, 38);
            this.TitleCheckBox.Name = "TitleCheckBox";
            this.TitleCheckBox.Size = new System.Drawing.Size(59, 23);
            this.TitleCheckBox.TabIndex = 0;
            this.TitleCheckBox.Text = "Title";
            this.TitleCheckBox.UseVisualStyleBackColor = true;
            this.TitleCheckBox.CheckedChanged += new System.EventHandler(this.TitleCheckBox_CheckedChanged);
            // 
            // CountryNameLabel
            // 
            this.CountryNameLabel.BackColor = System.Drawing.Color.Silver;
            this.CountryNameLabel.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountryNameLabel.Location = new System.Drawing.Point(593, 308);
            this.CountryNameLabel.Multiline = true;
            this.CountryNameLabel.Name = "CountryNameLabel";
            this.CountryNameLabel.Size = new System.Drawing.Size(243, 39);
            this.CountryNameLabel.TabIndex = 7;
            this.CountryNameLabel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CountryNameLabel.TextChanged += new System.EventHandler(this.CountryNameLabel_TextChanged);
            // 
            // ProgrammerLabel
            // 
            this.ProgrammerLabel.BackColor = System.Drawing.Color.Silver;
            this.ProgrammerLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProgrammerLabel.Location = new System.Drawing.Point(379, 400);
            this.ProgrammerLabel.Multiline = true;
            this.ProgrammerLabel.Name = "ProgrammerLabel";
            this.ProgrammerLabel.Size = new System.Drawing.Size(220, 39);
            this.ProgrammerLabel.TabIndex = 8;
            this.ProgrammerLabel.Text = "Prog Rammer";
            this.ProgrammerLabel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ProgrammerLabel.TextChanged += new System.EventHandler(this.ProgrammerLabel_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Flags.cs.Properties.Resources.France;
            this.pictureBox1.Location = new System.Drawing.Point(567, 99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(289, 193);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1362, 654);
            this.Controls.Add(this.ProgrammerLabel);
            this.Controls.Add(this.CountryNameLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.FlagViewerLabel);
            this.Name = "Form1";
            this.Text = "Viewer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FlagViewerLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton FranceRadioButton;
        private System.Windows.Forms.RadioButton USARadioButton;
        private System.Windows.Forms.RadioButton ColombiaRadioButton;
        private System.Windows.Forms.RadioButton PhilippinesRadioButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox ProgrammerCheckBox;
        private System.Windows.Forms.CheckBox CountryNameCheckBox;
        private System.Windows.Forms.CheckBox TitleCheckBox;
        private System.Windows.Forms.TextBox CountryNameLabel;
        private System.Windows.Forms.TextBox ProgrammerLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

